clc
clear
%%
% [~,B]=xlsread('E:\数据库\Pen-Based Recognition of Handwritten Digits Data Set\pendigits tes.xlsx');
% N=length(B);
% fea=zeros(N,16);
% gnd=zeros(N,1);
% for ni=1:N
%     dB=str2num(cell2mat(B(ni)));
%     pair=length(dB);
%     fea(ni,1:pair-1)=dB(1:pair-1);
%     gnd(ni)=dB(pair);
% end
% Selection='pendigits_tes';

% name={'Yale_32x32','ORL_32x32','JAFFE_64x64_expression','UMIST','2k2k'};

name={'ALOI','COIL100','Mfeat',...%3
    'BBCSport','CiteSeer','JAFFE_64x64',...%6
    'ORL_32x32','Yale_32x32','UMIST',...%9
    'Reuters_21578','handwritten','handwritten2',...%12
    'handwritten3','handwritten4','handwritten5',...%15
    'handwritten6','BDGP_fea','Reuters21578'};%18
parameter=[
3 ,1 ,1,5;%ALOI
3 ,1 ,1,5;%COIL100
3 ,0 ,5,5;%Mfeat
3 ,-1,3,5;%BBCSport
3 ,-1,1,10;%CiteSeer
2 ,1 ,2,5;%JAFFE
2 ,-1,4,5;%ORL
-1,0 ,3,5;%Yale
2 ,3 ,1,5;%UMIST
1 ,1 ,1,10;%Reuters_21578
2 ,2 ,4,5;%handwritten
2 ,1 ,3,5;
2 ,2 ,5,5;
2 ,2 ,5,5;
2 ,2 ,5,5;
0 ,-3, 1,10;
-5,-2, 1,10;
3 ,-2, 4,10;%BDGP
-3,-2, 2,10];

for iii=6
Selection=name{iii};
if ~exist('noise','var')
if strcmp(Selection,'JAFFE_64x64') || strcmp(Selection,'UMIST')
    load(strcat('D:\浙大数据集\',Selection,'.mat'));
    if size(fea,2)==length(gnd)
        fea=fea';
    end
elseif strcmp(Selection,'JAFFE_Salt_Pepper_noise_0') || strcmp(Selection,'UMIST_Salt_Pepper_noise_0')
    load(strcat('D:\图像训练集裁剪\',Selection,'.mat'));
    if length(gnd)==size(X,2)
        fea=X';
    else
        fea=X;
    end
elseif strcmp(Selection,'BDGP_fea')
     load(strcat('D:\BBC\multi-view-dataset\',Selection,'.mat'));
    fea=X{1};
    gnd=Y;
    clear X Y class_meaning data_name view_meaning
elseif strcmp(Selection,'Reuters21578')
    load(strcat('D:\浙大数据集\Reuters21578.mat'));
    load(strcat('D:\浙大数据集\Reuters21578_10Class\1.mat'));
    fea = fea(sampleIdx,:);
    gnd = gnd(sampleIdx,:);
    fea(:,zeroIdx) = [];
    clear sampleIdx zeroIdx
elseif strcmp(Selection,'handwritten')
    load('D:\BBC\ConsistentGraphLearning-master\data\handwritten.mat');
    fea=X{1};
    gnd=Y;
    clear X Y
elseif strcmp(Selection,'handwritten2')
    load('D:\BBC\ConsistentGraphLearning-master\data\handwritten.mat');
    fea=X{2};
    gnd=Y;
    clear X Y
elseif strcmp(Selection,'handwritten3')
    load('D:\BBC\ConsistentGraphLearning-master\data\handwritten.mat');
    fea=X{3};
    gnd=Y;
    clear X Y
elseif strcmp(Selection,'handwritten4')
    load('D:\BBC\ConsistentGraphLearning-master\data\handwritten.mat');
    fea=X{4};
    gnd=Y;
    clear X Y
elseif strcmp(Selection,'handwritten5')
    load('D:\BBC\ConsistentGraphLearning-master\data\handwritten.mat');
    fea=X{5};
    gnd=Y;
    clear X Y
elseif strcmp(Selection,'handwritten6')
    load('D:\BBC\ConsistentGraphLearning-master\data\handwritten.mat');
    fea=X{6};
    gnd=Y;
    clear X Y
elseif strcmp(Selection,'ALOI') ||strcmp(Selection,'BBCSport')||strcmp(Selection,'Reuters_21578')
    load(strcat('D:\BBC\Multi-view_Graph_Learning-master\data\',Selection,'.mat'));
    fea=fea{1,1};
    gnd=gt;
    clear gt
elseif strcmp(Selection,'CiteSeer')
    load(strcat('D:\BBC\Multi-view_Graph_Learning-master\data\',Selection,'.mat'));
    fea=fea{2};
    gnd=gt;
    clear gt
elseif strcmp(Selection,'2k2k') || strcmp(Selection,'PIE_11554')
    load(strcat('D:\浙大数据集\',Selection,'.mat'));
    clear testldx trainldx
elseif strcmp(Selection,'Mfeat')
    load('D:\BBC\multi-view-datasets-master\1-complete-data\Mfeat.mat');
    fea=double(data{1,1})';
    gnd=truth;
    clear data per10 per20 per30 per40 per50 per60 per70  truth
else
    load(strcat('D:\浙大数据集\',Selection,'.mat'));
end
else
    load(strcat('D:\浙大数据集\',Selection,'前3_salt_pepper_',num2str(100*noise),'.mat'));
end
Min=min(min(fea));
if strcmp(Selection,'COIL100')
fea=double(im2uint8(fea));
end
if Min<0
   fea=fea-Min;
end
total=unique(gnd);
exclude=[];
ceshi=setdiff(total,exclude);
%%
nr=length(ceshi);
r=[];
Tlabel=[];
for i=1:nr
    lr=find(gnd==ceshi(i));
    if size(lr,1)>size(lr,2)
        r=[r;lr];
    else
        r=[r;lr'];
    end
    Tlabel=[Tlabel;i*ones(length(lr),1)];
end
    X=fea';
X=X(:,r);
rX=sum(X,2);
X(rX==0,:)=[];
[n1,l1]=size(X);
s=nr;
n=n1;m=l1;
p=s;
P=parameter(iii,4);
Xv=X./max(max(X));
if strcmp(Selection,'2k2k')  || strcmp(Selection,'BDGP_fea')
distance='cosine';
DDh = pdist2(Xv',Xv','cosine'); 
else
distance='euclidean';
DDh = pdist2(Xv',Xv','euclidean'); 
end

limiter=100;
clear total lr fea DCol ceshi rX r trainIdx testIdx gnd

    tic
    [~, G1, evs,F] = CAN(X, nr,P);
    Time_can=toc;
    parfor i1=1:20
        la=litekmeans(F,nr,'Replicates',2);
        result_can = ClusteringMeasure(Tlabel, la);
        GC1(i1,:)=result_can;
    end
    D1=sparse(diag(sum(G1)));
    figure('name','Learned graph by G1'); 
    imshow(full(G1),[], 'border','tight'); colormap jet; colorbar;
    
    G2=G1*G1;
    D2 = diag(sum(G2));
    L2 = D2-G2;
    [F2, ~, ~]=eig1(full(L2), p, 0);%
    parfor i2=1:20
%         label2= litekmeans(F2,p,'Replicates',20);
%         GC2(t,:) = ClusteringMeasure(Tlabel, label2);
        la2=litekmeans(F2,nr,'Replicates',2);
        result_can2 = ClusteringMeasure(Tlabel, la2);
        GC2(i2,:)=result_can2;
    end
    figure('name','Learned graph by G2'); 
    imshow(full(G2),[], 'border','tight'); colormap jet; colorbar;
    
    G3=G2*G1;
    D3 = diag(sum(G3));
    L3 = D3-G3;
    [F3, ~, ~]=eig1(full(L3), p, 0);%
    parfor i3=1:20
%         label3= litekmeans(F3,p,'Replicates',20);
%         GC3(i3,:) = ClusteringMeasure(Tlabel, label3);
        la3=litekmeans(F3,nr,'Replicates',2);
        result_can3 = ClusteringMeasure(Tlabel, la3);
        GC3(i3,:)=result_can3;
    end
    figure('name','Learned graph by G3'); 
    imshow(full(G3),[], 'border','tight'); colormap jet; colorbar;
    
    G4=G3*G1;
    D4 = diag(sum(G4));
    L4 = D4-G4;
    [F4, ~, ~]=eig1(full(L4), p, 0);%
    parfor i4=1:20
%     label4= litekmeans(F4,p,'Replicates',20);
%     GC4(t,:) = ClusteringMeasure(Tlabel, label4);
        la4=litekmeans(F4,nr,'Replicates',2);
        result_can4 = ClusteringMeasure(Tlabel, la4);
        GC4(i4,:)=result_can4;
    end
    figure('name','Learned graph by G4'); 
    imshow(full(G4),[], 'border','tight'); colormap jet; colorbar;
    
    G5=G4*G1;
    D5 = diag(sum(G5));
    L5 = D5-G5;
    [F5, ~, ~]=eig1(full(L5), p, 0);%
    parfor i5=1:20
%     label5= litekmeans(F5,p,'Replicates',20);
%     GC5(t,:) = ClusteringMeasure(Tlabel, label5);
        la5=litekmeans(F5,nr,'Replicates',2);
        result_can5 = ClusteringMeasure(Tlabel, la5);
        GC5(i5,:)=result_can5;
    end
    figure('name','Learned graph by G5'); 
    imshow(full(G5),[], 'border','tight'); colormap jet; colorbar;
    
T=5;
index=5;
ME=zeros(T,index);
epsilon=10^-10;
Time_rnmfaog=0;
for t=1:T
H0=rand(m,p);
W0=rand(n,p);


    
    tic
    [WME21_S,S21_S,HME21_S,xishu,dd]=RNMFOG(X,W0,H0,G1,10^parameter(iii,1),10^parameter(iii,2),limiter,epsilon,parameter(iii,3),distance);
    Time_rnmfaog=Time_rnmfaog+toc;
    labelME21_S = litekmeans(HME21_S,p,'Replicates',20);
    [EntropyME21_S,PurityME21_S,FMeasureME21_S,AccuracyME21_S] = Fmeasure2(Tlabel',labelME21_S');
    MIhatME21_S = nmi2(Tlabel',labelME21_S');
    ME(t,:)=[EntropyME21_S,PurityME21_S,FMeasureME21_S,AccuracyME21_S,MIhatME21_S];
    
    if T==1
    figure('name','Learned graph by RNMFAOG'); 
    imshow(full(S21_S),[], 'border','tight'); colormap jet; colorbar;
    end
    

  
    
fprintf('实验次数=%d\n',t);
end
[mean(GC1,1),std(GC1,0,1)]

[mean(ME,1),std(ME,0,1)]
end
% end