function [Hs]=updateH_RNMFOG(X,W,H0,U,G,D,alpha,epsilon)
% first=U*X'*W+alpha*G*H0+beta*H0;
% second=U*H0*(W'*W)+alpha*D*H0+beta*E*H0;
first=U*X'*W+alpha*G*H0;
second=U*H0*(W'*W)+alpha*D*H0;
Hs=H0.*first./max(second,epsilon);
end