function [Ws]=updateW_RNMFOG(X,W0,H,U,epsilon)
first=X*U*H;
second=W0*(H'*U*H);
Ws=W0.*first./max(second,epsilon);
end