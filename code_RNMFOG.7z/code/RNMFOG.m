function [W0,S_star,H0,p,d,obj,Result]=RNMFOG(X,W0,H0,G1,lambda,alpha,limiter,epsilon,M,distance,Tlabel)
if nargin < 11
    Tlabel = [];
else
    nr=length(unique(Tlabel));
end
[~,num]=size(X);
% E=ones(num)/num;
G=cell(5,1);
G{1,1}=G1;
G{2,1}=G{1,1}*G{1,1};
G{3,1}=G{2,1}*G{1,1};
G{4,1}=G{3,1}*G{1,1};
G{5,1}=G{4,1}*G{1,1};
S_star=G{1,1};
% W=0;
% for o=1:5
%     W=W+G{o,1};
% end
% W=W/5;
S_star=sparse(S_star);
clear G1


D = diag(sum(S_star));
D=sparse(D);
SS_star=sparse(num,num);
% obj=[obj,objective_value(X,U0,V0,D,G,alpha,lambda)];
%%
obj=[];
Result=[];
%%
for iter=1:limiter
    U=X-W0*H0';
    E1=sqrt(sum(U.^2,1));
%     E2=sqrt(1+sum(U.^2,1));
    E2=sqrt(1+E1.^2);
    U=max(2.*E1.*E2,epsilon);
    U=diag(1./U);
    U=sparse(U);
%     clear E1 E2
    if ~isempty(Tlabel)
        obj= [obj;sum(log(E1+E2))+alpha*trace(H0'*(D-S_star)*H0)];
        Accuracy=0;MIhat=0;
        for k=1:10
            [a,b] = evalResults(H0',Tlabel);
            Accuracy=Accuracy+a;
            MIhat=MIhat+b;
        end
        Result=[Result;Accuracy/10,MIhat/10];
    end
    clear E1 E2 
    H=updateH_RNMFOG(X,W0,H0,U,S_star,D,alpha,epsilon);
    if norm(H-H0,'fro')<10^-10
        H0=H;
        break
    else
        H0=H; 
    end
    W0=updateW_RNMFOG(X,W0,H0,U,epsilon);

    
    
    p=zeros(5,1);
    loss=zeros(5,1);
    for o=1:5
       loss(o)=norm(S_star-G{o,1},'fro');
    end
    [~,order]=sort(loss);
    p(order(1:M))=1;
%     if norm(p-[1,0,0,0,0],2)==0
%         S=G{1,1};
%     else
%     d=zeros(5,1);
%     d(logical(p))=order(logical(p));
    d=0.5*p./(loss.*sqrt(loss.^2+1));
    d(d==inf)=1;
    S=0;
    for o=1:5
        S=S+d(o)*G{o,1};
    end
    S=S/(sum(d));
%     end
    if norm(S_star-SS_star,'fro')^2>10^-3
    SS_star=S_star;
    HH=H0./max(max(H0));
    if strcmp(distance,'euclidean')
%         distf =L2_distance_1(HH',HH');
        distf = pdist2(HH,HH,'euclidean');
    elseif strcmp(distance,'cosine')
        distf = pdist2(HH,HH,'cosine');
    end
%     Distf=sparse(diag(1./sqrt(sum(distf))));
%     distf=Distf*distf*Distf;
    clear HH
    S_star = zeros(num);
    for i=1:num
        dsi = S(i,:);
        dfi = distf(i,:);
        dfi=dfi/sum(dfi);
        ad = (dsi-0.5*lambda*dfi);
%         ad=max(ad)-ad;
%         ad = -(dxi+beta*dfi)/(2*r);%r is not updated, and as is negative
        S_star(i,:) = EProjSimplex_new(ad);
    end
    clear distf S
    S_star = max(S_star,S_star');
    S_star=sparse(S_star);
    D = diag(sum(S_star));
    D=sparse(D);
    end
end
end